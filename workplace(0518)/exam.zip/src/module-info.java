module exam {
	requires java.sql;
	requires ojdbc6;
}